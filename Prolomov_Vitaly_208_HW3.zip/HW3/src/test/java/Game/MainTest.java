package Game;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    @Test
    void printAllBalancesOnList() {
        List<Player> players= new ArrayList<>();
        players.add(new HonestPlayer());
        assertDoesNotThrow(()->Main.printAllBalances(players));
    }
}