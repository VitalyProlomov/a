package Game;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HonestPlayerTest {

    @Test
    void addHonestPlayer() {
        HonestPlayer honestPlayer1 = new HonestPlayer();
        HonestPlayer honestPlayer2 = new HonestPlayer();
        assertEquals(3, HonestPlayer.allHonestPlayers.size());
        assertDoesNotThrow(()->honestPlayer1.addHonestPlayer(honestPlayer2));
    }

}