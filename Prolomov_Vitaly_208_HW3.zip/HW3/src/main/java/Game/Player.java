package Game;

import java.util.Random;

/**
 * Represents abstract class of player - can be either honest player or a cheater.
 */
public abstract class Player extends Thread {

    protected static Random rnd = new Random();

    protected int balance;

    public int getBalance() {
        return balance;
    }

    /**
     * Reduces balance of current player by the submitted amount (or if it is more than balance, than
     * balance gets to zero.
     */
    protected void reduceBalance(int stolen_amount) {
        if (stolen_amount > CheaterPlayer.MAX_STOLEN_AMOUNT) {
            throw new IllegalArgumentException("Something went wrong.. Too much points were stolen");
        }
        balance-= stolen_amount;
        if (balance < 0) {
            balance = 0;
        }
    }

    /**
     * Gets random card from the deck and adds its points amount to the player`s balance.
     */
    protected synchronized void getCard() {
        int pulledCard = Deck.getTopCard();
        balance += pulledCard;
        if (Main.isTestModeOn) {
            System.out.println("Player " + this.getName() + " pulled out " + pulledCard +
                    ". Current balance: " + this.balance);
        }
    }
}
