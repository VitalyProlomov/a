package Game;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class CheaterPlayer extends Player {
    public static final int MAX_STOLEN_AMOUNT = 8;

    /**
     * runs the thread - cheater chooses to steal points random honest player with probability 0.4
     * and chooses to draw a card with probability of 0.6
     */
    @Override
    public void run() {
        int timeAsleep;
        while (!isInterrupted()) {
            double probability = rnd.nextDouble();
            // Choosing to steal or to get a card.
            if (probability > 0.4) {
                getCard();
                timeAsleep = 100 + (Math.abs(rnd.nextInt()) % 101);
            } else {
                int victimsAmount = HonestPlayer.allHonestPlayers.size();
                HonestPlayer victim =HonestPlayer.allHonestPlayers.get(Math.abs(rnd.nextInt()) % victimsAmount);
                int stolenAmount = steal(victim);
                timeAsleep = 180 + (Math.abs(rnd.nextInt()) % 121);
                if (Main.isTestModeOn) {
                    System.out.println("Player " + this.getName() + " stole " + stolenAmount +
                            " points from " + victim.getName() + ". Current balance: " + balance +  System.lineSeparator()+
                            "--[" + victim.getName() + " balance: " + victim.getBalance() + "]--");
                }
            }

            try {
                sleep(timeAsleep);
            } catch (InterruptedException e) {
                interrupt();
            }
        }
    }

    /**
     * Steals random amount of points in range [0;8] from random honest player.
     * (Reduces points from honest player and adds them to current cheater in the method)
     * @param player honest player - the one who gets his points stolen.
     * @return amount of stolen points.
     */
    private int steal(HonestPlayer player) {
        // Synchronized on player to prevent stealing from stealing at the same time and,
        // as a consequence, not changing players balance properly.
        synchronized (player) {
            int amountToSteal = Math.abs(rnd.nextInt()) % (MAX_STOLEN_AMOUNT + 1);
            if (player.getBalance() < amountToSteal) {
                this.balance += player.getBalance();
                // Cheater can not steal more points than victim has.
                amountToSteal = player.getBalance();
            } else {
                this.balance += amountToSteal;
            }
            player.reduceBalance(amountToSteal);
            return amountToSteal;
        }
    }

}
