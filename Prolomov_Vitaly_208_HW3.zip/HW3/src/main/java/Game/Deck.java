package Game;

import java.util.Random;

/**
 * Represents the deck from which players draw cards with points from 1 to 10.
 */
public class Deck {
    static final int MAX_CARD = 10;
    static final int MIN_CARD = 1;

    private static final Random randCard = new Random();

    /**
     * @return amount of points that player got from the deck.
     */
    protected static int getTopCard() {
        return MIN_CARD + (Math.abs(randCard.nextInt()) % MAX_CARD);
    }

}
