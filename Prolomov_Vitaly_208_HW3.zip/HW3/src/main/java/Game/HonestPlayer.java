package Game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HonestPlayer extends Player{

    /**
     * Creates new Honest player and adds itself to the static list o all honest players
     */
    protected HonestPlayer() {
        allHonestPlayers.add(this);
    }

    // List that contains all honest players that were created during the work of the program.
    protected static List<HonestPlayer> allHonestPlayers = new ArrayList<>();

    public void addHonestPlayer(HonestPlayer player) {
        allHonestPlayers.add(player);
    }

    /**
     * Draws random amount of points from the deck while the program is not finished.
     */
    @Override
    public void run() {
        while (!isInterrupted()) {
            getCard();
            int timeAsleep = 100 + (Math.abs(rnd.nextInt()) % 101);

            try {
                sleep(timeAsleep);
            } catch (InterruptedException e) {
                interrupt();
            }
        }
    }
}
