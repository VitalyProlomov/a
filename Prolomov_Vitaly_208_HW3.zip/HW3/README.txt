In my realization there are several things I would like to clarify in this file.

1) Max amount of honest players in one game is 20. Same for cheaters. 
Minimal amount of hobest plyers is 1, minimal cheaters amount is 0.

2) In my program several cheaters can NOT steal the cards from the same honest player at one time. That is done to prevent problems such as the following:
Assume that we have Honest player H1 with balance 5
and 2 Cheaters: C1 and C2.
Suppose they are stealing the 5 points from H1 at the same time (they switched to each other during the work process).
Then they both will get additional 5 points added to their balance (since teh H1 balance will not update) and H1 balance will get to 0.
So, to get rid of such problems, I decided to make this constraint.

3) Meanwhile, cheater can steal the card of an honest player H, while H is taking the card himself (that seems more realistic, than making any constraints and does not create any sorts of problems) 